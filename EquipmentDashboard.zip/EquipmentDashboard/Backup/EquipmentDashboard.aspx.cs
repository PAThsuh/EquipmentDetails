﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.DataVisualization.Charting;

namespace EquipmentDashboard
{
    public partial class EquipmentDashboard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            LoadChart();
        }

        private void LoadChart()
        {
            ChartArea equipmentArea = EquipmentDetails.ChartAreas["EquipmentDetailsArea"];
            Series equipmentSeries = EquipmentDetails.Series["EquipmentDetailsSeries"];

            equipmentArea.AxisX.Title = "Equipment Type";
            equipmentArea.AxisY.Title = "Number Of Equipment";

            List<EquipmentChart> equipmentChart = new List<EquipmentChart>();
            equipmentChart.Add(new EquipmentChart() { EquipmentType = "Yet", NumberOfEquipment=10 });
            equipmentChart.Add(new EquipmentChart() { EquipmentType = "Mod", NumberOfEquipment=30 });
            equipmentChart.Add(new EquipmentChart() {EquipmentType= "POD", NumberOfEquipment=50 });

            equipmentSeries.XValueMember = "EquipmentType";
            equipmentSeries.YValueMembers = "NumberOfEquipment";

            EquipmentDetails.DataSource = equipmentChart;
        }

        private void GetEquipmentDetails()
        {
                        // HTTP GET.  
            using (var client = new HttpClient())  
           {  
               // Setting Base address.  
               client.BaseAddress = new Uri("https://localhost:44334/");  
  
               // Setting content type.  
                 client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));  
  
               // Initialization.  
               HttpResponseMessage response = new HttpResponseMessage();  
  
               // HTTP GET  
               response = await client.GetAsync("api/WebApi?" + requestParams).ConfigureAwait(false);  
  
               // Verification  
               if (response.IsSuccessStatusCode)  
               {  
                  // Reading Response.  
                  string result = response.Content.ReadAsStringAsync().Result;  
                  responseObj = JsonConvert.DeserializeObject<DataTable>(result);  
               }  
            } 
        }
    }

    public class EquipmentChart
    {
        public string EquipmentType { get; set; }
        public int NumberOfEquipment { get; set; }
    }
}