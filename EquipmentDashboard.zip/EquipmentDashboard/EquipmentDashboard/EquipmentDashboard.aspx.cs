﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.DataVisualization.Charting;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Data;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Configuration;

namespace EquipmentDashboard
{
    public partial class EquipmentDashboard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            DataTable equipmentResult = new DataTable();
            DataTable datResult;
            string requestParams = string.Empty;

            int max = 100;
            int last = Convert.ToInt32(ConfigurationManager.AppSettings["Max"]);
            string APIUrl = ConfigurationManager.AppSettings["APIUrl"];

            do
            {
                requestParams = string.Format("apikey=SC:demo:64a9aa122143a5db&max={0}&last={1}", max, last);

                datResult = GetEquipmentDetails(requestParams, APIUrl).Result;

                if (datResult != null && datResult.Rows.Count > 0)
                    equipmentResult.Merge(datResult);

                last += max;
            }
            while (datResult != null && datResult.Rows.Count >= max);

            LoadChart(equipmentResult);
        }

        private void LoadChart(DataTable equipmentResult)
        {
            ChartArea equipmentArea = EquipmentDetails.ChartAreas["EquipmentDetailsArea"];
            Series equipmentSeries = EquipmentDetails.Series["EquipmentDetailsSeries"];

            equipmentArea.AxisX.Title = "Equipment Type";
            equipmentArea.AxisX.TitleFont = new System.Drawing.Font("sans-serif", 10.00F, System.Drawing.FontStyle.Bold);

            equipmentArea.AxisX.LabelStyle.Interval = 1;
            equipmentArea.AxisX.LabelStyle.Font= new System.Drawing.Font("sans-serif", 10.00F, System.Drawing.FontStyle.Bold);

            equipmentArea.AxisY.Title = "Number Of Equipment";
            equipmentArea.AxisY.TitleFont = new System.Drawing.Font("sans-serif", 10.00F, System.Drawing.FontStyle.Bold);

            if (equipmentResult != null)
            {
                if (equipmentResult.AsEnumerable().Where(result => result["OperationalStatus"].ToString() == "Operational") != null )
                {
                    int operationalCount = equipmentResult.AsEnumerable().Where(result => result["OperationalStatus"].ToString() == "Operational").Count();
                    lblOperational.Text += operationalCount.ToString();
                    lblNonOperational.Text += (equipmentResult.Rows.Count - operationalCount).ToString();

                }
                else
                {
                    lblOperational.Text += "0";
                    lblNonOperational.Text += equipmentResult.Rows.Count.ToString();
                }

                var resultCategory = (from result in equipmentResult.AsEnumerable()
                                  group result by result.Field<string>("AssetCategoryID") into byCategory
                                  select new
                                  {
                                      EquipmentType = byCategory.Key,
                                      NumberOfEquipment = byCategory.Count()
                                  });

                equipmentSeries.XValueMember = "EquipmentType";
                equipmentSeries.YValueMembers = "NumberOfEquipment";

                EquipmentDetails.DataSource = resultCategory;
            }
        }

        private static async Task<DataTable> GetEquipmentDetails(string requestParams,string APIUrl)
        {
            DataTable responseResult = new DataTable();

            using (var client = new HttpClient())  
           {  
               client.BaseAddress = new Uri(APIUrl);  
  
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));  
  
               HttpResponseMessage response = new HttpResponseMessage();  
  
               response = await client.GetAsync(string.Format("api/Asset/Asset/All?{0}",requestParams)).ConfigureAwait(false);  

                if (response.IsSuccessStatusCode)  
               {  
                  string result = response.Content.ReadAsStringAsync().Result;
                    responseResult = JsonConvert.DeserializeObject<DataTable>(result);  
               }  
            }

            return responseResult;
        }
    }

    public class EquipmentChart
    {
        public string EquipmentType { get; set; }
        public int NumberOfEquipment { get; set; }
    }
}